"""A sample plugin for the catalogue's fixtures; nothing runs it."""
